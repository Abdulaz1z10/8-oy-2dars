import React from 'react'

export default function Genre() {
  return (
    <div>
      <h1 className='text-black ml-[20px]'>Genre</h1>
    </div>
  )
}
