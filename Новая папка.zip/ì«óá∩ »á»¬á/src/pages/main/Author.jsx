import React from 'react'

export default function Author() {
  return (
    <div>
      <h1 className='text-black ml-[20px]'>Author</h1>
    </div>
  )
}
